//function hoisting example

function example() {
    animalSound(); // "The lion roars!"
  
    function animalSound() {
      console.log("The lion roars!");
    }
  
    animalSound(); // "The lion roars!"
  
    var animalSound = function() {
      console.log("The cat meows!");
    };
  
    animalSound(); // "The cat meows!"
  }
  
  example();