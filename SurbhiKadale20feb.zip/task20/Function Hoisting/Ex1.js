//Simple example of function hoisting

function example() {
    sayHello(); // "Hello from outer function!"
  
    function sayHello() {
      console.log("Hello from outer function!");
    }
  
    if (true) {
      function sayHello() {
        console.log("Hello from inner function!");
      }
    }
  
    sayHello(); // "Hello from inner function!"
  }
  
  example();