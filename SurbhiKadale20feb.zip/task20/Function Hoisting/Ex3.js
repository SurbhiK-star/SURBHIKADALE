//example demonstrating function hoisting with multiple functions and a mix of function declarations 

sayHello(); // Output: Hello, John! (hoisted function declaration)

var myName = "Vaishnavi";

function sayHello() {
  console.log("Hello, " + myName + "!");
}

sayHello(); // Output: Hello, Vaishnavi! (after function definition)

myName = "Anushka"; // Variable assignment without var, let, or const

sayHello(); // Output: Hello, Anushka! (updated variable)

var sayGoodbye = function() {
  console.log("Goodbye, " + myName + "!");
};

sayGoodbye(); // Output: Goodbye, Anushka! (function expression)

function greetPerson(person) {
  console.log("Hello, " + person + "!");
}

greetPerson("Anu"); // Output: Hello, Anu! (function declaration)

function sayName() {
  var name = "Bobby";
  console.log("My name is " + name);
}

sayName(); // Output: My name is Bobby (function declaration with local variable)