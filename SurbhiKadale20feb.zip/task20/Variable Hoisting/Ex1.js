//Variable Hoisting 

console.log(x); // Output: undefined
var x = 5;

// Equivalent to:
var x; // Declaration is hoisted
console.log(x); // Output: undefined
x = 5; // Initialization remains here