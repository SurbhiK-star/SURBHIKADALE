//variable hosting example
function example() {
    console.log("Before variable declaration: ", x); // Output: undefined
    console.log("Before variable declaration: ", y); // Output: ReferenceError: y is not defined
  
    var x = 10;
  
    if (x === 10) {
      var y = 20;
      console.log("Inside if block: ", x, y); // Output: 10 20
    }
  
    console.log("Outside if block: ", x, y); // Output: 10 20
  
    function innerFunction() {
      var z = 30;
      console.log("Inside function: ", x, y, z); // Output: 10 20 30
    }
  
    innerFunction();
  
    console.log("After function call: ", x, y); // Output: ReferenceError: z is not defined
  }
  
  example();