//varibale hosting example
function example() {
    console.log("Before variable declaration in example(): ", a); // Output: undefined
    console.log("Before variable declaration in example(): ", b); // Output: ReferenceError: b is not defined
  
    var a = 1;
  
    if (a === 1) {
      var b = 2;
      console.log("Inside if block: ", a, b); // Output: 1 2
  
      var c = 3;
      let d = 4;
      const e = 5;
  
      console.log("Inside if block: ", c, d, e); // Output: 3 4 5
    }
  
    console.log("Outside if block: ", a, b); // Output: 1 2
    // console.log("Outside if block: ", c, d, e); // Throws ReferenceError: c is not defined
  
    function innerFunction() {
      var f = 6;
      let g = 7;
      const h = 8;
  
      console.log("Inside function: ", a, b, f, g, h); // Output: 1 2 6 7 8
    }
  
    innerFunction();
  
    // Attempting to access f, g, or h outside their scope results in a ReferenceError
    // console.log("After function call: ", a, b, f, g, h); // Throws ReferenceError: f is not defined
  }
  
  example();