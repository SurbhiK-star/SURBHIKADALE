//example of a closure in JavaScript

function createCounter() {
    let count = 0;
  
    function increment() {
      count++;
      console.log("Count:", count);
    }
  
    function decrement() {
      count--;
      console.log("Count:", count);
    }
  
    function getCount() {
      return count;
    }
  
    return {
      increment,
      decrement,
      getCount
    };
  }
  const counter = createCounter();
  counter.increment(); // Output: Count: 1
  counter.increment(); // Output: Count: 2
  counter.increment(); // Output: Count: 3
  console.log("Final count:", counter.getCount()); // Output: Final count: 3