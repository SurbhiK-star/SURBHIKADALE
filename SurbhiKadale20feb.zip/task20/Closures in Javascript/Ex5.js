//example demonstrating closures in a loop using an array of functions

function createFunction(i) {
    return function() {
      console.log(i);
    };
  }
  
  const functions = [];
  for (let i = 0; i < 3; i++) {
    functions.push(createFunction(i));
  }
  
  functions.forEach(func => func());