//simple example of closure in JavaScript:

function outerFunction() {
    let outerVariable = "I'm outer!";
  
    function innerFunction() {
      console.log(outerVariable); // Inner function has access to outerVariable
    }
  
    return innerFunction;
  }
  
  const innerFunc = outerFunction();
  innerFunc(); // Output: I'm outer!