//example that demonstrates closures in a loop using let instead of var

for (let i = 0; i < 3; i++) {
    setTimeout(function() {
      console.log(i);
    }, 1000);
  }